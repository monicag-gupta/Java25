package factory;

public class Factory {
	static Books getBooks(String category) {
		if(category.equals("School")) {
			return new SchoolBooks();
		}
		return new ComputerBooks();
	}

	public static void main(String[] args) {
		Books b=Factory.getBooks("School");
		System.out.println(b.noOfPage() + b.author());

	}

}
