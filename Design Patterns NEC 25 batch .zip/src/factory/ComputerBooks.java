package factory;

public class ComputerBooks implements Books
{

	public int noOfPage() {
		return 10000;
	}

	public String author() {
		return "Anonymous";
	}
	

}
