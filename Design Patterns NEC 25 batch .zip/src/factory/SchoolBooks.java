package factory;

public class SchoolBooks implements Books
{

	public int noOfPage() {
		return 100;
	}

	public String author() {
		return "NCERT";
	}
	

}
