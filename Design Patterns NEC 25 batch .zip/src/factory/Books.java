package factory;

public interface Books {
	int noOfPage();
	String author();
}
