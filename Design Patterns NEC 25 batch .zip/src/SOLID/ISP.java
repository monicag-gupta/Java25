package SOLID;
interface xeroxISP{
	void scan();
	void print();
}
interface XeroxEditISP{
	void edit();
}
class HPISP implements xeroxISP{
	public void scan() {
		System.out.println("HP Scanning");
	}
	public void print() {
		System.out.println("HP Printing");
	}
}
class CanonISP implements xeroxISP{
	public void scan() {
		System.out.println("Canon Scanning");
	}
	public void print() {
		System.out.println("Canon Printing");
	}
}
class PhotoEditorISP implements xeroxISP, XeroxEditISP {
	public void scan() {
		System.out.println("Photo Scanning");
	}
	public void print() { }

	public void edit() {
		System.out.println("Photo Editing");
	}
}
public class ISP {

	public static void main(String[] args) {
			HPISP hp=new HPISP();
			hp.print();
			hp.scan();

	}

}
