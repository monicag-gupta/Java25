package SOLID;
import java.util.*;
class Birds{
	public void eat() {
		System.out.println("Bird is Eating");
	}
	public void fly() {
		System.out.println("Bird is Flying");
	}
}

class Ostrich extends Birds{ //Ostrich is not substitutable for Birds as it cannot fly
	public void fly() {
		throw new ArithmeticException("I dont have wings..sorry");
	}
	public void run() {
		System.out.println("Bird is Running");
	}
}
class Dragon extends Birds{
	public void eat() {
		System.out.println("Bird is Eating fireballs");
	}
	public void firing() {
		System.out.println("Bird is firing");
	}
}
class BirdsLSP{
	public void eat() {
		System.out.println("Bird is Eating");
	}	
}
class FlyingBirdsLSP extends BirdsLSP{
	public void fly() {
		System.out.println("Bird is flying");
	}	
}
class OstrichLSP extends BirdsLSP{ //Ostrich is not substitutable for Birds as it cannot fly
	public void run() {
		System.out.println("Bird is Running");
	}
}
class DragonLSP extends FlyingBirdsLSP{
	public void eat() {
		System.out.println("Bird is Eating fireballs");
	}
	public void firing() {
		System.out.println("Bird is firing");
	}
}

public class LSP {
	static void fn(Birds b) { 
		b.eat();
		//b.fly();
	}
	static void fnLSP(BirdsLSP b) { 
		b.eat();
	}

	public static void main(String[] args) {
		List<Birds> birds=new ArrayList<>();
		birds.add(new Ostrich());
		birds.add(new Dragon());
		for(Birds b : birds) {
			fn(b);
		}
		
		List<BirdsLSP> bird=new ArrayList<>();
		bird.add(new OstrichLSP());
		bird.add(new DragonLSP());
		for(BirdsLSP b : bird) {
			fnLSP(b);
		}
		
		

	}

}
