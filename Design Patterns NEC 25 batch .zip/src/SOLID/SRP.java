package SOLID;
class NotInSRP{
	void print() {
		System.out.println("Printer is printing");
	}
	void scan() {
		System.out.println("Scanner is scanning");
	}
}
class InSRPPrint{
	void print() {
		System.out.println("Printer is printing");
	}
}
class InSRPScan{
	void scan() {
		System.out.println("Scanner is scanning");
	}
}

public class SRP {
	public static void main(String[] args) {
		NotInSRP a1=new NotInSRP();
		a1.print();
		a1.scan();
		
		InSRPPrint a2=new InSRPPrint();
		a2.print();
		
		InSRPScan a3=new InSRPScan();
		a3.scan();
	}

}
