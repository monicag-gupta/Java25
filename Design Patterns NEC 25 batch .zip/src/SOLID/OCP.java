package SOLID;

class VehicleLicenceOffice{
	public void Car() {
		System.out.println("Car Licence");
	}
	public void Bike() {
		System.out.println("Bike Licence");
	}
}
//If The client needs to add the truck licence , then we need to modify the code
//So the above is not in OCP

abstract class OCPVehicleLicenceOffice{
	public void Licence() {
		System.out.println("Licence");
	}
}


class Car extends OCPVehicleLicenceOffice{
	public void Licence() {
		System.out.println("Car Licence");
	}
}

class Bike extends OCPVehicleLicenceOffice{
	public void Licence() {
		System.out.println("Bike Licence");
	}
}
//Here we can extend and get the truck licence very easily
public class OCP {

	public static void main(String[] args) {
		Car c=new Car();
		c.Licence();

	}

}
