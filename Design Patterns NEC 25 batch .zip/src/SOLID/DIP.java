package SOLID;
class ClientBanking{
	netBanking nb;
	ClientBanking(netBanking n){
		this.nb=n;
	}
	public void BankOperations() {
		nb.fn();
	}
}
class ClientBankingDIP{
	Banking b;
	ClientBankingDIP(Banking n){
		this.b=n;
	}
	public void BankOperations() {
		b.fn();
	}
}

interface Banking{
	void fn();
}
class netBanking implements Banking{
	public void fn() {
		System.out.println("Net Banking done");
	}
}
class ManualBanking implements Banking{
	public void fn() {
		System.out.println("Manual Banking done");
	}
}




public class DIP {

	public static void main(String[] args) {
		ClientBanking cb=new ClientBanking(new netBanking());
		cb.BankOperations();
		ClientBankingDIP SBI=new ClientBankingDIP(new netBanking());
		SBI.BankOperations();
		ClientBankingDIP SBI2=new ClientBankingDIP(new ManualBanking());
		SBI2.BankOperations();

	}

}
