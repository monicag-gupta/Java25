package SOLID;
interface xerox{
	void scan();
	void print();
	void edit();
}
class HP implements xerox{
	public void scan() {
		System.out.println("HP Scanning");
	}
	public void print() {
		System.out.println("HP Printing");
	}
	@Override
	public void edit() {}
	
}
class Canon implements xerox{
	public void scan() {
		System.out.println("Canon Scanning");
	}
	public void print() {
		System.out.println("Canon Printing");
	}
	@Override
	public void edit() {}
}
class PhotoEditor implements xerox{
	public void scan() {
		System.out.println("Photo Scanning");
	}
	public void print() { }
	@Override
	public void edit() {
		System.out.println("Photo Editing");
	}
}
public class NotInISP {

	public static void main(String[] args) {
			HP hp=new HP();
			hp.print();
			hp.scan();

	}

}
