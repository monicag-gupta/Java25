package prototype;
class A{
	String s;
	A(){}
	A(String ss){s=ss;}
	public String getS() {
		return s;
	}

	public void setS(String s) {
		this.s = s;
	}
}
class PrototypeOfA{
	A a=new A();
	PrototypeOfA(){}
	PrototypeOfA(String s){
		a.setS(s);
	}
	public void setA(String s) {
		a.setS(s);
	}
	public String getA() {
		return a.getS();
	}
}

class ProxyOfA{
	A a=new A();
	ProxyOfA(){}
	ProxyOfA(A s){
		this.a=s;
	}
	public void setA(A s) {
		a.setS(s.getS());
	}
	public A getA() {
		A a2=new A();
		a2.setS(a.getS());
		return a2;
	}
	
	
}

public class SimplePrototype {

	public static void main(String[] args) {
		PrototypeOfA p=new PrototypeOfA();
		p.setA("Value");
		System.out.println(p.getA());
		ProxyOfA pp=new ProxyOfA();
		pp.setA(new A("String Value"));
		System.out.println(pp.getA().getS());
		
		
		

	}

}
